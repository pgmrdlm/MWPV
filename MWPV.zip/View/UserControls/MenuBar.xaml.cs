﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace MWPV.View.UserControls
{
    public partial class MenuBar : UserControl
    {
        private Window? _logWindow;

        public MenuBar()
        {
            InitializeComponent();
        }

        // Tools -> View Logs
        private void mnuToolsViewLogs_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // If already open, just bring it to front
                if (_logWindow is { IsVisible: true })
                {
                    _logWindow.Activate();
                    return;
                }

                // Host the ViewLogs user control in a simple window
                _logWindow = new Window
                {
                    Title = "Log Viewer",
                    Width = 1000,
                    Height = 640,
                    Owner = Window.GetWindow(this),
                    Content = new MWPV.View.Logs.ViewLogs()
                };
                _logWindow.Closed += (_, __) => _logWindow = null;
                _logWindow.Show();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine("[MenuBar] View Logs failed: " + ex);
            }
        }
    }
}
