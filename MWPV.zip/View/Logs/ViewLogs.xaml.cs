﻿// View/Logs/ViewLogs.xaml.cs
using System;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Threading;
using System.Windows.Controls;
using MWPV.Services;
using Utilities.Helpers;

// Alias the model so it doesn't clash with the namespace MWPV.View.Logs
using LogRow = MWPV.Models.Logs;

namespace MWPV.View.Logs
{
    public partial class ViewLogs : UserControl
    {
        public ObservableCollection<LogRow> LogCatalog { get; } = new();

        public ViewLogs()
        {
            InitializeComponent();
            DataContext = this;

            Loaded += async (_, __) =>
            {
                try
                {
                    await LogCatalogService.ReloadIntoAsync(
                        LogCatalog,
                        DatabaseHelper.GetAppOpenConnection,
                        CancellationToken.None);
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"[ViewLogs] initial load failed: {ex}");
                }
            };
        }
    }
}
