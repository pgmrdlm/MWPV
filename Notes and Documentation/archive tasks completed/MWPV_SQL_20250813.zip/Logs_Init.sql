-- Creates the Logs table and common indexes if they don't exist.
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS Logs (
    Id            INTEGER PRIMARY KEY AUTOINCREMENT,
    CreatedUtc    INTEGER    NOT NULL,         -- unix epoch seconds (UTC)
    Level         TEXT       NOT NULL,         -- TRACE/INFO/WARN/ERROR/FATAL
    Source        TEXT,                         -- e.g., APP, UI, AUTH
    EventCode     TEXT,                         -- e.g., App.Login.Success
    CorrelationId TEXT,
    SessionId     TEXT,
    MachineId     TEXT       NOT NULL,
    AppVersion    TEXT       NOT NULL,
    IsCrash       INTEGER    NOT NULL CHECK (IsCrash IN (0,1)),
    Payload       BLOB       NOT NULL,         -- encrypted bytes
    PayloadFmt    TEXT       NOT NULL,         -- e.g., json+aesgcm
    PayloadVer    INTEGER    NOT NULL,
    KeySetVersion INTEGER    NOT NULL,
    StackHash     TEXT,
    Reserved1     TEXT,
    Reserved2     TEXT
);

-- Helpful indexes
CREATE INDEX IF NOT EXISTS IX_Logs_CreatedUtc   ON Logs (CreatedUtc DESC);
CREATE INDEX IF NOT EXISTS IX_Logs_IsCrash      ON Logs (IsCrash, CreatedUtc DESC);
CREATE INDEX IF NOT EXISTS IX_Logs_SessionId    ON Logs (SessionId, CreatedUtc DESC);
CREATE INDEX IF NOT EXISTS IX_Logs_Event        ON Logs (EventCode, CreatedUtc DESC);
