-- Inserts a single log row using the v2 schema.
-- Bind the parameters shown below. All are nullable except where noted.
-- Expectation: DB schema includes these columns (see Logs_Init.sql).
INSERT INTO Logs
(CreatedUtc, Level, Source, EventCode, CorrelationId, SessionId, MachineId, AppVersion, IsCrash,
 Payload, PayloadFmt, PayloadVer, KeySetVersion, StackHash, Reserved1, Reserved2)
VALUES
(@CreatedUtc, @Level, @Source, @EventCode, @CorrelationId, @SessionId, @MachineId, @AppVersion, @IsCrash,
 @Payload, @PayloadFmt, @PayloadVer, @KeySetVersion, @StackHash, @Reserved1, @Reserved2);
