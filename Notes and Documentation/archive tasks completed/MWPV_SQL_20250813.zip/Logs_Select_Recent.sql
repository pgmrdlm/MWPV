-- Returns recent rows, optionally filtered to crashes only.
-- Bind @Limit (INTEGER, required). Bind @CrashesOnly to 1 or 0 (or NULL for all).
SELECT Id, Payload
FROM Logs
WHERE (@CrashesOnly IS NULL OR IsCrash = @CrashesOnly)
ORDER BY Id DESC
LIMIT @Limit;
