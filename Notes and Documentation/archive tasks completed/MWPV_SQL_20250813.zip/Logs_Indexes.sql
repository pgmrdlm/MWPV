-- Recreate/ensure indexes (can be rerun safely).
CREATE INDEX IF NOT EXISTS IX_Logs_CreatedUtc   ON Logs (CreatedUtc DESC);
CREATE INDEX IF NOT EXISTS IX_Logs_IsCrash      ON Logs (IsCrash, CreatedUtc DESC);
CREATE INDEX IF NOT EXISTS IX_Logs_SessionId    ON Logs (SessionId, CreatedUtc DESC);
CREATE INDEX IF NOT EXISTS IX_Logs_Event        ON Logs (EventCode, CreatedUtc DESC);
